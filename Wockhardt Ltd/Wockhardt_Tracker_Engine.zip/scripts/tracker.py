"""
Wockhardt Ltd Tracker — main script (GitHub-hosted version)

WHAT THIS DOES, EVERY TIME IT RUNS:
1. Asks Wockhardt's website for its list of files, newest first (the
   "media inventory" shortcut discovered earlier), filtered to PDFs only.
2. Compares against data/seen.json (a memory of what's already been
   processed) to find anything genuinely new.
3. For each new PDF: downloads it, sends it to Claude to classify — is it
   Investor-Relations/Press related, which category, one-line summary,
   and is it regulatory.
4. If NOT relevant -> skip entirely, mark as seen, move on.
5. If relevant -> saves a copy of the PDF into the matching folder under
   "Wockhardt Ltd/<Category>/", and adds one entry to
   data/tracker_data.json (the file the dashboard webpage reads).

This script does NOT push anything to GitHub itself — that's handled by
the workflow file (.github/workflows/tracker.yml), which commits and
pushes any files this script creates/changes, automatically, after it runs.
"""

import os
import sys
import re
import json
import time
import base64
import logging
import datetime
import requests

# ---- CONFIG ----------------------------------------------------------------

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMPANY_FOLDER = os.path.join(REPO_ROOT, "Wockhardt Ltd")
DATA_FILE = os.path.join(REPO_ROOT, "data", "tracker_data.json")
SEEN_FILE = os.path.join(REPO_ROOT, "data", "seen.json")

MEDIA_API_URL = "https://www.wockhardt.com/wp-json/wp/v2/media"
MEDIA_PER_PAGE = 25
MEDIA_MAX_PAGES = 4

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL = "claude-haiku-4-5-20251001"

MAX_RETRIES = 3
BACKOFF_BASE_SECONDS = 5

# IMPORTANT: these folder names must exactly match the sub-folders you
# created under "Wockhardt Ltd" in your GitHub repo. If you used different
# names, edit the right-hand side of each line below to match exactly.
CATEGORY_TO_FOLDER = {
    "Annual Report": "Annual Reports",
    "Financial Result": "Financial Results",
    "Press Release": "Press Releases",
    "Board Outcome": "Board Meeting Outcomes",
    "Shareholding Pattern": "Shareholding Pattern",
    "Credit Rating": "Credit Rating Updates",
    "Litigation-Regulatory Notice": "Litigation and Regulatory Notices",
    "USFDA-Regulatory Inspection": "USFDA and Regulatory Inspections",
    "Related-Party Transaction": "Related Party Transactions",
    "M&A-Strategic": "MA and Strategic Announcements",
    "Other": "Other",
}

REGULATORY_CRITERIA = """
Flag as regulatory/high-priority (Yes) if the document is any of:
- A filing addressed to BSE/NSE or SEBI
- Anything affecting share capital or control (allotments, buybacks, open
  offers, promoter shareholding changes, credit rating actions)
- Litigation or regulatory notices/orders
- USFDA or other drug-regulator inspection outcomes (Form 483, warning
  letters, import alerts, EIR)
- M&A or strategic transactions
- Related-party transactions above materiality thresholds
- Anything referencing a specific business line/product in a way that
  suggests legal exposure
Otherwise flag No.
"""

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("wockhardt_tracker")


# ---- RETRY HELPER -----------------------------------------------------------

def with_retry(fn, *args, what="operation", **kwargs):
    last_err = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            last_err = e
            wait = BACKOFF_BASE_SECONDS * (2 ** (attempt - 1))
            log.warning(f"{what} failed (attempt {attempt}/{MAX_RETRIES}): {e}. Retrying in {wait}s.")
            if attempt < MAX_RETRIES:
                time.sleep(wait)
    log.error(f"{what} failed after {MAX_RETRIES} attempts: {last_err}")
    raise last_err


# ---- STATE (seen documents + dashboard data) --------------------------------

def load_json(path, default):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def safe_filename(name: str) -> str:
    name = re.sub(r'[\\/:*?"<>|]', "_", name)
    return name.strip()[:150]


# ---- STEP 1: FETCH RECENT PDFs FROM WOCKHARDT'S MEDIA INVENTORY -------------

def fetch_recent_pdfs() -> list[dict]:
    docs = []
    for page in range(1, MEDIA_MAX_PAGES + 1):
        def call():
            resp = requests.get(
                MEDIA_API_URL,
                params={
                    "per_page": MEDIA_PER_PAGE,
                    "page": page,
                    "orderby": "date",
                    "order": "desc",
                    "mime_type": "application/pdf",
                },
                timeout=20,
                headers={"User-Agent": "Mozilla/5.0"},
            )
            resp.raise_for_status()
            return resp.json()

        try:
            items = with_retry(call, what=f"media API page {page}")
        except Exception:
            break

        if not items:
            break

        for item in items:
            docs.append({
                "wp_id": item["id"],
                "title": item.get("title", {}).get("rendered", "").strip() or f"Untitled document {item['id']}",
                "url": item.get("source_url", ""),
                "publication_date": item.get("date", ""),
            })

    return docs


def fetch_pdf_bytes(url: str) -> bytes:
    resp = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0"})
    resp.raise_for_status()
    return resp.content


# ---- STEP 2: CLASSIFY VIA CLAUDE --------------------------------------------

def classify_document(doc: dict, pdf_bytes: bytes) -> dict:
    pdf_b64 = base64.standard_b64encode(pdf_bytes).decode("utf-8")

    prompt_text = f"""You are classifying a document found on Wockhardt Ltd's
website for a law firm's investor-relations/press-release monitoring
tracker. This document was found in the site's general file inventory,
which includes files unrelated to investors/press (e.g. product images,
brochures, marketing material).

Document title: {doc['title']}
Document URL: {doc['url']}

{REGULATORY_CRITERIA}

First decide: is this an Investor Relations or Press Release type document
at all (e.g. financial results, annual report, annual return, board
outcome, shareholding pattern, credit rating, litigation/regulatory
notice, USFDA/regulatory inspection, related-party transaction, M&A
announcement, or a press release)? If NOT — if it's clearly unrelated
(e.g. a product photo, marketing brochure, factory image) — set
"is_relevant" to false and leave the other fields as reasonable defaults.

Respond ONLY with JSON, no preamble, no markdown fences, in this exact shape:
{{
  "is_relevant": true or false,
  "document_type": "<one of: Annual Report, Financial Result, Press Release,
   Board Outcome, Shareholding Pattern, Credit Rating,
   Litigation-Regulatory Notice, USFDA-Regulatory Inspection,
   Related-Party Transaction, M&A-Strategic, Other>",
  "one_line_summary": "<plain English, one sentence>",
  "regulatory_flag": "Yes" or "No",
  "regulatory_reason": "<one short sentence, or empty string if No>"
}}
"""

    def call():
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": ANTHROPIC_MODEL,
                "max_tokens": 500,
                "messages": [{
                    "role": "user",
                    "content": [
                        {
                            "type": "document",
                            "source": {"type": "base64", "media_type": "application/pdf", "data": pdf_b64},
                        },
                        {"type": "text", "text": prompt_text},
                    ],
                }],
            },
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()

    data = with_retry(call, what=f"Claude classification ({doc['url']})")
    text = data["content"][0]["text"].replace("```json", "").replace("```", "").strip()
    return json.loads(text)


# ---- STEP 3: SAVE COPY INTO THE RIGHT FOLDER --------------------------------

def save_copy(pdf_bytes: bytes, category: str, original_title: str, wp_id: int) -> str:
    """
    Saves the PDF into Wockhardt Ltd/<matching folder>/, returns the path
    relative to the repo root (used both for the dashboard link and for
    git to commit the new file).
    """
    folder_name = CATEGORY_TO_FOLDER.get(category, "Other")
    folder_path = os.path.join(COMPANY_FOLDER, folder_name)
    os.makedirs(folder_path, exist_ok=True)

    filename = f"{safe_filename(original_title)}_{wp_id}.pdf"
    full_path = os.path.join(folder_path, filename)

    with open(full_path, "wb") as f:
        f.write(pdf_bytes)

    # path relative to repo root, using forward slashes (for use in URLs)
    rel_path = os.path.relpath(full_path, REPO_ROOT).replace(os.sep, "/")
    return rel_path


# ---- MAIN --------------------------------------------------------------------

def run():
    seen = load_json(SEEN_FILE, {"ids": []})
    seen_ids = set(seen.get("ids", []))

    dashboard_data = load_json(DATA_FILE, [])

    try:
        candidates = fetch_recent_pdfs()
    except Exception as e:
        log.error(f"Could not fetch the media inventory: {e}")
        candidates = []

    new_count = 0
    for doc in candidates:
        did = str(doc["wp_id"])
        if did in seen_ids:
            continue

        log.info(f"Checking new file: {doc['title']}")

        try:
            pdf_bytes = with_retry(fetch_pdf_bytes, doc["url"], what=f"download {doc['url']}")
        except Exception as e:
            log.error(f"Could not download {doc['url']}: {e} — will retry next run.")
            continue  # don't mark as seen; try again next run

        try:
            classification = classify_document(doc, pdf_bytes)
        except Exception as e:
            log.error(f"Classification failed for {doc['url']}: {e} — will retry next run.")
            continue  # don't mark as seen; try again next run

        seen_ids.add(did)  # only mark seen once we've successfully classified it

        if not classification.get("is_relevant", False):
            log.info(f"Not relevant, skipping: {doc['title']}")
            continue

        category = classification.get("document_type", "Other")
        rel_path = save_copy(pdf_bytes, category, doc["title"], doc["wp_id"])

        entry = {
            "title": doc["title"],
            "publication_date": doc.get("publication_date", ""),
            "date_detected": datetime.datetime.utcnow().isoformat(),
            "document_type": category,
            "one_line_summary": classification.get("one_line_summary", ""),
            "regulatory_flag": classification.get("regulatory_flag", "No"),
            "regulatory_reason": classification.get("regulatory_reason", ""),
            "original_link": doc["url"],
            "archived_copy_path": rel_path,
        }
        dashboard_data.append(entry)
        new_count += 1
        log.info(f"Added to tracker: {doc['title']} -> {category}")

    # newest first for the dashboard
    dashboard_data.sort(key=lambda x: x.get("publication_date", ""), reverse=True)

    save_json(DATA_FILE, dashboard_data)
    save_json(SEEN_FILE, {"ids": list(seen_ids)})

    log.info(f"Run complete. {new_count} new relevant document(s) added.")


if __name__ == "__main__":
    run()
